(ns app.config)

(def debug?
  ^boolean goog.DEBUG)
